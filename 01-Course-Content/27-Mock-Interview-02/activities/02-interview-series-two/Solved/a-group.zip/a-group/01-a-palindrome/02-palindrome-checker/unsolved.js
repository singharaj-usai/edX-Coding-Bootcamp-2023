// Palindrom Possibility Checker

