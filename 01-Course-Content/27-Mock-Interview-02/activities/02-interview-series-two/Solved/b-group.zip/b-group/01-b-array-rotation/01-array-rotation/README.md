# INTERVIEW QUESTIONS

## Array rotation

## Instructions
Given an array and a number, n. Rotate the elements in the array n spaces to the left. 

If an element is at the beginning of the array, it should be rotated to the back of it.

## Example
Given [1,2,3,4,5,6] and 3, your algorithm should output: [4,5,6,1,2,3]

## Optimal Time
O(n)