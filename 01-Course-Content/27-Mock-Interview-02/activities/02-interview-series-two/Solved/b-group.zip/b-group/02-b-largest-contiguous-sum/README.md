# INTERVIEW QUESTIONS

## Largest Contiguous Sum

## Instructions
Given an array of integers, find the maximum subarray i.e largest sum of a contiguous subarray

## Example
Test Case 1: [2,5,-1,3,-10,9,7,4]    
Expected Output: *20 (9+7+4)*

Test Case 2: [2,5,-1,3,-10,-1,-2,-3]    
Expected Output: *9 (2+5+(-1)+3)*

## Optimal Time
O(n^2)