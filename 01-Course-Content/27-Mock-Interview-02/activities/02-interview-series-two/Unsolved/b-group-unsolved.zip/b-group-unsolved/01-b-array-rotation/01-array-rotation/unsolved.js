// array-rotation

