# Computer Science

## Stacks (L.I.F.O) delete middle of it without using any additional data structure.

## Instructions

Given a stack with push(), pop(), empty() operations, delete the middle of it without using any additional data structure.